<link rel="stylesheet" href="../assets/css/bootstrap.min.css"/>
<link href="../assets/font-awesome-4.1.0/css/font-awesome.min.css" rel="stylesheet" type="text/css"/>
<link href="../assets/css/style.css" rel="stylesheet"/>
<script src="../assets/js/jquery-1.10.2.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>
<link rel="stylesheet" href="../assets/css/bootstrapValidator.min.css"/>
<script src="../assets/js/bootstrapValidator.js"></script>
<a href="../system/usrv.php" class="btn btn-danger">Change Host</a>
<a href="../system/udb.php" class="btn btn-info">Set Database</a>
<a href="../system/udbmenu.php" class="btn btn-success">Menu</a>
<a href="../application/index.php" class="btn btn-default">DB Admin</a>
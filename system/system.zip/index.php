<?php
header("location:../application/");
?>
<?php
$baseconfurl = "../application/config";
$hostfilename = "$baseconfurl/Host.php";
$dbfilename = "$baseconfurl/Database.php";
//$keyfilename = "";
?>